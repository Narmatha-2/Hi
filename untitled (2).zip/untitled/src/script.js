JS

const events = [

{ title: "AI in Fashion", category: "tech", date: "2025-10-10" },

{ title: "Embroidery Workshop", category: "workshop", date: "2025-10-15" },

{ title: "Sustainable Fashion Expo", category: "fashion", date: "2025-10-20" },

{ title: "Tailoring Tech Talk", category: "tech", date: "2025-10-25" },

];

function loadEvents(filtered = "all") {

const container = document.getElementById("eventList");

container.innerHTML = "";

const filteredEvents = filtered === "all"

? events

: events.filter(e => e.category === filtered);

filteredEvents.forEach(event => {

const card = document.createElement("div");

card.className = "event-card";

card.innerHTML = `

<h3>${event.title}</h3>

<p>Category: ${event.category}</p>

<p>Date: ${event.date}</p>

`;

container.appendChild(card);

});

}

function filterEvents(category) {

loadEvents(category);

}

function registerEvent() {

const name = document.getElementById("name").value;

const email = document.getElementById("email").value;

const eventName = document.getElementById("eventName").value;

if (name && email && eventName) {

document.getElementById("confirmation").innerText =

`Thank you, ${name}! You’ve registered for "${eventName}".`;

}

}

window.onload = () => loadEvents();